# Premium Web Design Agent — Quick Start

## Setup (1 minute)

1. Copy `SKILL.md` into your Claude Code skills directory
2. No config file needed — this skill works out of the box

## First Run

> "Design a landing page for [your product] — dark theme, modern, conversion-focused"

> "Build a pricing page with 3 tiers"

> "Create a dashboard UI with sidebar nav, stats cards, and a data table"

> "Redesign this page to look more premium" (paste current code)

## Tips

- Be specific about the vibe: "dark glassmorphism", "light editorial", "bold brutalist", "clean minimal"
- Mention your brand colors and fonts if you have them
- The agent generates production-ready code (React + Tailwind by default)
- Ask for "mobile-first" if responsive is important
- Request specific interactions: "add hover animations", "scroll-triggered reveals", "micro-interactions"
