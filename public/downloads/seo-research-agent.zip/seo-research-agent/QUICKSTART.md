# SEO Research Agent — Quick Start

## Setup (3 minutes)

1. Copy `SKILL.md` into your Claude Code skills directory
2. Copy these templates to your workspace (remove `.template` from filenames):
   - `seo-config.template.json` → `seo-config.json`
   - `seo-tracker.template.json` → `seo-tracker.json`
3. Edit `seo-config.json`:
   - Set your website URL and industry
   - Add 3-5 primary keywords you want to rank for
   - Add 2-3 competitor URLs
   - Set your content strategy (blog URL, posting frequency)

## First Run

> "Run an SEO audit on my homepage"

> "Research keyword opportunities for [your main keyword]"

> "Analyze my top 3 competitors' SEO strategy"

> "Generate a content brief for the keyword [your target keyword]"

## Weekly Workflow

1. **Monday:** "Run weekly SEO scan" — checks rankings, finds new opportunities
2. **Wednesday:** "Generate a content brief for [keyword]" — plan next blog post
3. **Friday:** "Show SEO progress this week" — review tracker

## Tips

- Start with 3-5 realistic keywords, not 20 aspirational ones
- Add competitors you actually compete with for traffic, not just business competitors
- The agent works best when you feed it your Google Search Console data (export CSV and share)
- Focus on long-tail keywords first — easier wins, faster results
