# Customer Support Agent — Quick Start

## Setup (5 minutes)

1. Copy `SKILL.md` into your Claude Code skills directory
2. Copy these templates to your workspace (remove `.template` from filenames):
   - `support-config.template.json` → `support-config.json`
   - `support-kb.template.json` → `support-kb.json`
   - `support-tickets.template.json` → `support-tickets.json`
3. Edit `support-config.json`:
   - Set your company name, product, and support email
   - Adjust the tone to match your brand
   - Add escalation keywords that should flag for human review
   - Set your SLA targets
4. Edit `support-kb.json`:
   - Replace example FAQs with your actual FAQs
   - Add known issues and workarounds
   - Fill in your plans, pricing, and refund policy

## First Run

> "A customer says: 'I can't log in to my account.' Draft a support response."

> "Categorize and respond to this ticket: 'When will you add dark mode?'"

> "Show me open support tickets"

## Building Your Knowledge Base

The more you add to `support-kb.json`, the better the responses get:
- After every real support interaction, add new Q&A pairs
- Log known issues as they come up
- Update product info when features or pricing change

## Tips

- Start with your 10 most common questions in the KB
- Set escalation keywords for anything requiring human judgment (refunds, legal, security)
- The agent gets smarter as you grow the KB — treat it like a living document
- Review auto-generated responses before sending to customers until you trust the quality
