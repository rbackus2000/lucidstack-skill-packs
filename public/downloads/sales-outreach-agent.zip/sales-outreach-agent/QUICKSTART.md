# Sales Outreach Agent — Quick Start

## Setup (5 minutes)

1. Copy `SKILL.md` into your Claude Code skills directory
2. Copy `outreach-config.example.json` → `outreach-config.json` in your workspace
3. Edit `outreach-config.json`:
   - Define your Ideal Customer Profile (ICP): industry, company size, roles
   - Set your product info and value propositions
   - Customize email templates and follow-up sequences
   - Add your sender info and signature

## First Run

> "Research [company name] and draft a cold outreach email"

> "Build a prospect list of 10 companies in [industry]"

> "Write a 3-email follow-up sequence for [product]"

> "Score this lead: [company name, role, industry]"

## Daily Workflow

1. **Prospect:** "Find 5 new leads matching my ICP" — builds prospect list
2. **Draft:** "Draft outreach for [prospect name]" — personalized email
3. **Follow up:** "Show me prospects needing follow-up" — check tracker
4. **Track:** "Update [prospect] status to [replied/meeting/closed]"

## Tips

- The more specific your ICP, the better the prospecting. "B2B SaaS, 10-50 employees, Series A" beats "tech companies."
- Always personalize — the agent researches each prospect. Let it find the hook.
- Follow-up sequences should be 3-5 emails spaced 3-5 days apart.
- Track everything in the outreach tracker so the agent learns what works.
