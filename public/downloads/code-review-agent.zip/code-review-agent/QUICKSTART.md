# Code Review Agent — Quick Start

## Setup (2 minutes)

1. Copy `SKILL.md` into your Claude Code skills directory
2. Copy `review-config.template.json` → `review-config.json` in your workspace
3. Edit `review-config.json` with your project details:
   - Set your language and framework
   - Toggle review focus areas on/off
   - Add your team's coding conventions
   - Set severity levels for your project

## Usage

**Review a file:**
> "Review src/app/api/auth/route.ts for security issues"

**Review a PR/changeset:**
> "Review the last 3 commits for code quality"

**Full project scan:**
> "Run a security audit on the src/api directory"

**Custom focus:**
> "Review this file focusing on performance and accessibility"

## Tips

- Start with one file to calibrate the review style
- Adjust `severity_levels` to match what your team cares about
- Add your linting rules to `conventions` so reviews don't duplicate linter warnings
- Use `ignore_patterns` to skip generated code, tests, or vendor files
