# Code Review Agent — Quick Start

## Where to Put Your Files

### Claude Code (CLI)

```
your-project/
├── .claude/
│   └── skills/
│       └── code-review-agent/
│           └── SKILL.md          ← copy here
├── review-config.json            ← copy template here, rename, fill in
└── (your project files)
```

1. Create `.claude/skills/code-review-agent/` in your project
2. Copy `SKILL.md` into that folder
3. Copy `review-config.template.json` to your project root as `review-config.json`
4. Edit `review-config.json` with your project details
5. Start Claude Code and ask: "Review src/app/api/auth/route.ts"

### Claude.ai (Projects)

1. Go to claude.ai → Create or open a Project
2. Click **"Set project instructions"** → paste the entire contents of `SKILL.md`
3. Click **"Add content"** → upload `review-config.json` (your filled-in config)
4. Start chatting: "Review this code for security issues" and paste your code

### OpenClaw

1. Copy `SKILL.md` into `~/.openclaw/workspace/skills/code-review-agent/`
2. Copy your filled-in `review-config.json` into `~/.openclaw/workspace/`
3. The agent picks it up automatically on next session

---

## Configuration (2 minutes)

1. Copy `review-config.template.json` → `review-config.json`
2. Edit these fields:
   - **project.language** — your primary language (typescript, python, go, etc.)
   - **project.framework** — your framework (nextjs, fastapi, express, etc.)
   - **review_focus** — toggle what matters: security, performance, testing, accessibility
   - **conventions** — your team's rules (naming, max line length, etc.)
   - **severity_levels** — customize what counts as critical vs. low
   - **ignore_patterns** — skip generated code, tests, vendor files

## Usage

**Review a file:**
> "Review src/app/api/auth/route.ts for security issues"

**Review recent changes:**
> "Review the last 3 commits for code quality"

**Full project scan:**
> "Run a security audit on the src/api directory"

**Custom focus:**
> "Review this file focusing on performance and accessibility"

## Tips

- Start with one file to calibrate the review style
- Adjust `severity_levels` to match what your team cares about
- Add your linting rules to `conventions` so reviews don't duplicate linter warnings
- Use `ignore_patterns` to skip generated code, tests, or vendor files
