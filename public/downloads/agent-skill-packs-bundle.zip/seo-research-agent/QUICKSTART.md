# SEO Research Agent — Quick Start

## Where to Put Your Files

### Claude Code (CLI)

```
your-project/
├── .claude/
│   └── skills/
│       └── seo-research-agent/
│           └── SKILL.md            ← copy here
├── seo-config.json                 ← your SEO settings
├── seo-tracker.json                ← ranking tracker
└── (your project files)
```

1. Create `.claude/skills/seo-research-agent/` in your project
2. Copy `SKILL.md` into that folder
3. Copy the two template files to your project root (remove `.template` from names):
   - `seo-config.template.json` → `seo-config.json`
   - `seo-tracker.template.json` → `seo-tracker.json`
4. Fill in your website, keywords, and competitors (see Configuration below)
5. Start Claude Code and ask: "Run an SEO audit on my homepage"

### Claude.ai (Projects)

1. Go to claude.ai → Create or open a Project
2. Click **"Set project instructions"** → paste the entire contents of `SKILL.md`
3. Click **"Add content"** → upload both:
   - `seo-config.json` (your settings)
   - `seo-tracker.json` (empty tracker to start)
4. Start chatting: "Research keyword opportunities for [your keyword]"

### OpenClaw

1. Copy `SKILL.md` into `~/.openclaw/workspace/skills/seo-research-agent/`
2. Copy your two config files into `~/.openclaw/workspace/`
3. The agent picks them up automatically on next session

---

## Configuration (3 minutes)

### seo-config.json (required)
- **website.url** — Your website URL
- **website.industry** — Your industry (e.g., "developer tools", "e-commerce", "SaaS")
- **website.target_audience** — Who you're trying to reach

### Keywords (required)
- **primary_keywords** — 3-5 main keywords you want to rank for
- **secondary_keywords** — 5-10 long-tail keywords (easier wins)
- Keep it focused. "AI commit logger" is better than "AI tools" for a niche product.

### Competitors (recommended)
- Add 2-3 competitors you actually compete with for search traffic
- Include their URL — the agent will analyze their content and keyword strategy

### Content Strategy (optional)
- Blog URL, posting frequency, target word count
- Helps the agent generate content briefs that match your publishing cadence

---

## First Run

> "Run an SEO audit on my homepage"

> "Research keyword opportunities for [your main keyword]"

> "Analyze my top 3 competitors' SEO strategy"

> "Generate a content brief for the keyword [your target keyword]"

## Weekly Workflow

1. **Monday:** "Run weekly SEO scan" — checks rankings, finds new opportunities
2. **Wednesday:** "Generate a content brief for [keyword]" — plan next blog post
3. **Friday:** "Show SEO progress this week" — review tracker

## Tips

- Start with 3-5 realistic keywords, not 20 aspirational ones
- Focus on long-tail keywords first — easier wins, faster results
- Add competitors you compete with for traffic, not just business competitors
- The agent works best with Google Search Console data — export CSV and share it
- Update your tracker weekly to build a history of ranking changes
