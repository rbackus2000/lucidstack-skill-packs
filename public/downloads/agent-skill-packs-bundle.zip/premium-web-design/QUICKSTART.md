# Premium Web Design Agent — Quick Start

## Where to Put Your Files

### Claude Code (CLI)

```
your-project/
├── .claude/
│   └── skills/
│       └── premium-web-design/
│           └── SKILL.md            ← copy here
└── (your project files)
```

1. Create `.claude/skills/premium-web-design/` in your project
2. Copy `SKILL.md` into that folder
3. No config file needed — this skill works out of the box
4. Start Claude Code and ask: "Design a landing page for [your product]"

### Claude.ai (Projects)

1. Go to claude.ai → Create or open a Project
2. Click **"Set project instructions"** → paste the entire contents of `SKILL.md`
3. No additional files needed
4. Start chatting: "Build a modern pricing page with 3 tiers"

### OpenClaw

1. Copy `SKILL.md` into `~/.openclaw/workspace/skills/premium-web-design/`
2. Works immediately on next session

---

## No Config Needed

This skill works without any configuration. Just tell it what you want and specify the vibe.

**Pro tip:** For best results, include these details in your request:
- **Theme:** dark, light, editorial, glassmorphism, brutalist, minimal
- **Colors:** your brand colors (or let it choose)
- **Fonts:** your brand fonts (or let it choose)
- **Framework:** React + Tailwind (default), or specify Vue, Svelte, vanilla HTML
- **Reference:** "like Linear's website" or "inspired by Stripe's pricing page"

---

## Usage

**Landing page:**
> "Design a landing page for [your product] — dark theme, modern, conversion-focused"

**Dashboard:**
> "Create a dashboard UI with sidebar nav, stats cards, and a data table"

**Pricing page:**
> "Build a pricing page with 3 tiers — light theme, clean, Space Grotesk font"

**Redesign:**
> "Redesign this page to look more premium" (paste current code)

**Component:**
> "Build a testimonial carousel with glassmorphism cards and smooth animations"

## Tips

- Be specific about the vibe — "dark glassmorphism" gets better results than "modern"
- Mention brand colors and fonts if you have them
- The agent generates production-ready code (React + Tailwind by default)
- Ask for "mobile-first" if responsive matters
- Request specific interactions: "hover animations", "scroll reveals", "micro-interactions"
- Paste existing code and ask for improvements — it's great at redesigns
