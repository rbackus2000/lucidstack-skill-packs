# Sales Outreach Agent — Quick Start

## Where to Put Your Files

### Claude Code (CLI)

```
your-project/
├── .claude/
│   └── skills/
│       └── sales-outreach-agent/
│           └── SKILL.md                ← copy here
├── outreach-config.json                ← your ICP and templates
└── (your project files)
```

1. Create `.claude/skills/sales-outreach-agent/` in your project
2. Copy `SKILL.md` into that folder
3. Copy `outreach-config.example.json` to your project root as `outreach-config.json`
4. Fill in your ICP, product info, and email templates (see Configuration below)
5. Start Claude Code and ask: "Research [company] and draft a cold email"

### Claude.ai (Projects)

1. Go to claude.ai → Create or open a Project
2. Click **"Set project instructions"** → paste the entire contents of `SKILL.md`
3. Click **"Add content"** → upload `outreach-config.json` (your filled-in config)
4. Start chatting: "Build a prospect list of 10 companies in [industry]"

### OpenClaw

1. Copy `SKILL.md` into `~/.openclaw/workspace/skills/sales-outreach-agent/`
2. Copy your filled-in `outreach-config.json` into `~/.openclaw/workspace/`
3. The agent picks it up automatically on next session

---

## Configuration (5 minutes)

Copy `outreach-config.example.json` → `outreach-config.json` and fill in:

### Ideal Customer Profile (required)
- **target_industries** — Industries you sell to (e.g., "SaaS", "E-commerce", "FinTech")
- **company_size** — Employee range (e.g., "10-200")
- **target_roles** — Job titles you sell to (e.g., "CTO", "VP Engineering", "Head of Product")
- **qualifying_signals** — What makes a lead hot (e.g., "recently raised funding", "hiring engineers")

### Your Product (required)
- **name** — Your product name
- **value_prop** — One sentence: what problem you solve
- **proof_points** — Social proof, metrics, case studies
- **pricing** — Rough pricing for qualification

### Email Templates (recommended)
- **cold_intro** — First touch email template with personalization slots
- **follow_up_1** — 3-day follow-up
- **follow_up_2** — 7-day follow-up
- **breakup** — Final "closing the loop" email

---

## First Run

> "Research [company name] and draft a cold outreach email"

> "Build a prospect list of 10 companies in [industry]"

> "Write a 3-email follow-up sequence for [product]"

> "Score this lead: [company name, role, industry]"

## Daily Workflow

1. **Prospect:** "Find 5 new leads matching my ICP" — builds prospect list
2. **Draft:** "Draft outreach for [prospect name]" — personalized email
3. **Follow up:** "Show me prospects needing follow-up" — check tracker
4. **Track:** "Update [prospect] status to [replied/meeting/closed]"

## Tips

- The more specific your ICP, the better the prospecting. "B2B SaaS, 10-50 employees, Series A" beats "tech companies."
- Always personalize — the agent researches each prospect before drafting
- Follow-up sequences should be 3-5 emails spaced 3-5 days apart
- Track everything in the outreach tracker so you know what's working
