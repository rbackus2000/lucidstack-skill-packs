# Customer Support Agent — Quick Start

## Where to Put Your Files

### Claude Code (CLI)

```
your-project/
├── .claude/
│   └── skills/
│       └── customer-support-agent/
│           └── SKILL.md                ← copy here
├── support-config.json                 ← your support settings
├── support-kb.json                     ← your knowledge base
├── support-tickets.json                ← ticket tracker
└── (your project files)
```

1. Create `.claude/skills/customer-support-agent/` in your project
2. Copy `SKILL.md` into that folder
3. Copy the three template files to your project root (remove `.template` from names):
   - `support-config.template.json` → `support-config.json`
   - `support-kb.template.json` → `support-kb.json`
   - `support-tickets.template.json` → `support-tickets.json`
4. Fill in your config and knowledge base (see Configuration below)
5. Start Claude Code and ask: "A customer says they can't log in. Draft a response."

### Claude.ai (Projects)

1. Go to claude.ai → Create or open a Project
2. Click **"Set project instructions"** → paste the entire contents of `SKILL.md`
3. Click **"Add content"** → upload all three:
   - `support-config.json` (your settings)
   - `support-kb.json` (your FAQs and product info)
   - `support-tickets.json` (empty tracker to start)
4. Start chatting: "Respond to this customer ticket: [paste ticket]"

### OpenClaw

1. Copy `SKILL.md` into `~/.openclaw/workspace/skills/customer-support-agent/`
2. Copy your three config files into `~/.openclaw/workspace/`
3. The agent picks them up automatically on next session

---

## Configuration (10 minutes)

### support-config.json (required)
- **company.name** — Your company name
- **company.product** — Your product name
- **company.support_email** — Where to escalate issues
- **company.tone** — How your support team sounds (e.g., "Friendly, casual, solution-first")
- **escalation_keywords** — Words that should flag for human review (e.g., "refund", "cancel", "legal")
- **sla** — Your response and resolution time targets

### support-kb.json (required — this is the big one)
- **faqs** — Your most common questions and answers. Start with your top 10.
- **known_issues** — Current bugs with workarounds
- **product_info** — Plans, pricing, refund policy, supported platforms

The more you add to the knowledge base, the better the agent responds. Treat this as a living document — add new Q&As after every real support interaction.

### support-tickets.json (auto-managed)
- Starts empty — the agent fills this in as it processes tickets
- Tracks open/closed tickets, categories, resolution times

---

## First Run

> "A customer says: 'I can't log in to my account.' Draft a support response."

> "Categorize this ticket: 'When will you add dark mode?'"

> "Show me open support tickets"

> "Draft a response to: 'I want a refund, this product is broken'"

## Tips

- Start with your 10 most common questions in the KB — this covers 80% of tickets
- Set escalation keywords for anything needing human judgment (refunds, legal, security)
- Review auto-generated responses before sending until you trust the quality
- After each real support interaction, add the Q&A to your KB — it compounds fast
