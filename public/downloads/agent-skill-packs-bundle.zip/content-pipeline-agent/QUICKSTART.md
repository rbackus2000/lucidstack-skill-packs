# Content Pipeline Agent — Quick Start

## Where to Put Your Files

### Claude Code (CLI)

```
your-project/
├── .claude/
│   └── skills/
│       └── content-pipeline-agent/
│           └── SKILL.md                ← copy here
├── content-config.json                 ← your brand config
├── content-calendar.json               ← your editorial calendar
└── (your project files)
```

1. Create `.claude/skills/content-pipeline-agent/` in your project
2. Copy `SKILL.md` into that folder
3. Copy `content-config.template.json` to your project root as `content-config.json`
4. Copy `content-calendar.template.json` to your project root as `content-calendar.json`
5. Fill in `content-config.json` with your brand details (see Configuration below)
6. Start Claude Code and ask: "What should I post this week?"

### Claude.ai (Projects)

1. Go to claude.ai → Create or open a Project
2. Click **"Set project instructions"** → paste the entire contents of `SKILL.md`
3. Click **"Add content"** → upload both:
   - `content-config.json` (your filled-in brand config)
   - `content-calendar.json` (your editorial calendar)
4. Start chatting: "Draft a LinkedIn post about [your topic]"

### OpenClaw

1. Copy `SKILL.md` into `~/.openclaw/workspace/skills/content-pipeline-agent/`
2. Copy your filled-in `content-config.json` and `content-calendar.json` into `~/.openclaw/workspace/`
3. The agent picks them up automatically on next session

---

## Configuration (5 minutes)

Copy `content-config.template.json` → `content-config.json` and fill in:

### Brand (required)
- **name** — Your brand or company name
- **voice** — How you write. Be specific: "Confident, technical, slightly irreverent" not just "professional." Include 2-3 example posts you've written if possible.
- **topics** — 3-5 topics you cover (e.g., "AI tools", "indie hacking", "developer productivity")
- **products** — Each product with name, URL, and one-liner description
- **hashtags** — 3-5 hashtags you regularly use

### Platforms (required)
- Toggle each platform on/off
- Set posting frequency: "daily", "2x/week", "weekly"
- Only enable platforms you're actually active on

### Content Pillars (recommended)
- 3-5 recurring themes for your content
- Examples: "Behind-the-scenes building", "Industry hot takes", "Tactical tutorials"

### Monitoring (optional)
- Search queries for daily trend scanning
- Competitor domains to watch
- Industry keywords

---

## First Run

Try these to test your setup:

> "Scan for trending topics in [your industry] and give me 5 content ideas"

> "What should I post this week?"

> "Draft a LinkedIn post about [your product's key feature]"

> "Run the daily content pipeline"

## Daily Workflow

1. **Morning:** "Run the daily content pipeline" — scans trends, drafts scheduled posts
2. **Review:** "Show me what's pending approval" — review and approve drafts
3. **Publish:** "Post [id]" — publishes approved content
4. **Repurpose:** "Turn this LinkedIn post into a Twitter thread" — cross-platform content

## Tips

- Fill in the `voice` field with how YOU write, not how you want AI to write
- Start with 2 platforms, not 5. Add more once you have a rhythm.
- 80/20 rule: 80% value content, 20% product mentions
- Review every draft before publishing until you trust the quality
- The agent gets better as you edit drafts — it learns your preferences over time
