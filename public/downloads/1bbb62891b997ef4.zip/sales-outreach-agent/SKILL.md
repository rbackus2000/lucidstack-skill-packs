---
name: sales-outreach-agent
description: Automated B2B sales outreach agent. Researches leads, crafts personalized cold emails, manages follow-up sequences, and tracks engagement. Built for founders and solo sales teams who need enterprise-grade outreach without the headcount.
---

# Sales Outreach Agent

## Overview

This skill transforms your AI agent into a dedicated sales development representative. It handles the entire outreach pipeline: lead research, email personalization, follow-up cadence management, and response analysis.

## Capabilities

### 1. Lead Research & Intelligence

When given a company name, domain, or person's name:

**Research Workflow:**
1. Search for the company website, LinkedIn, Crunchbase, and recent news
2. Identify key decision-makers (CEO, CTO, VP Sales, etc.)
3. Extract company details: size, industry, funding stage, tech stack, recent announcements
4. Find personal details: role, tenure, recent posts/articles, mutual connections
5. Score the lead (1-10) based on ICP fit

**Output Format:**
```
## Lead Brief: [Company Name]

**Company:** [Description]
**Size:** [Employee count] | **Industry:** [Sector]
**Funding:** [Stage/amount if applicable]
**Tech Stack:** [Known technologies]
**Recent News:** [Relevant announcements]

### Key Contacts
| Name | Title | LinkedIn | Email Pattern |
|------|-------|----------|---------------|
| [Name] | [Role] | [URL] | [pattern] |

**ICP Score:** [X/10]
**Why They Fit:** [1-2 sentences]
**Angle:** [Suggested approach based on research]
```

### 2. Personalized Email Drafting

**Principles:**
- First line references something specific about the recipient (recent post, company news, shared connection)
- No generic "I hope this finds you well" openers
- Value proposition in 1-2 sentences max
- Clear, low-friction CTA (question, not a calendar link dump)
- Under 150 words total
- Written like a human, not a template

**Email Framework:**
```
Subject: [Specific, curiosity-driven, under 6 words]

[Personal hook — reference their specific situation, post, or company event]

[1-2 sentences on the problem you solve, framed around THEIR pain]

[Social proof — one line, specific result]

[CTA — simple question, not a demand]

[Name]
```

**Customization Parameters:**
- `tone`: casual | professional | technical (default: casual)
- `product`: The product/service being sold
- `value_prop`: Core value proposition
- `social_proof`: Key customer results or logos
- `cta_style`: question | soft-ask | direct (default: question)

### 3. Follow-Up Sequence Management

**Default Cadence (customizable):**
- **Day 0:** Initial outreach
- **Day 3:** Follow-up #1 — add new value (case study, insight, resource)
- **Day 7:** Follow-up #2 — different angle or channel
- **Day 14:** Follow-up #3 — breakup email (last touch, no pressure)

**Each follow-up:**
- References the previous email without being passive-aggressive
- Adds NEW information (never just "bumping this up")
- Gets progressively shorter
- Final email is graceful exit with open door

**Tracking:**
Store outreach state in `memory/outreach-tracker.json`:
```json
{
  "leads": {
    "company-name": {
      "contact": "Name",
      "email": "email@company.com",
      "status": "follow-up-1",
      "initial_sent": "2026-03-01",
      "last_touch": "2026-03-04",
      "next_touch": "2026-03-08",
      "notes": "Opened initial email, no reply",
      "sequence_position": 2,
      "total_touches": 4
    }
  }
}
```

### 4. Response Analysis

When a lead replies:
1. Classify response: interested | objection | not-now | not-interested | referral
2. Draft appropriate reply based on classification
3. Update tracker with response details
4. If objection: prepare counter with specific data/proof points
5. If interested: draft meeting request with 2-3 time options

## Configuration

Create `outreach-config.json` in your workspace:

```json
{
  "company": "Your Company Name",
  "product": "Your Product",
  "value_prop": "One sentence value proposition",
  "social_proof": [
    "Company X increased revenue 40% in 3 months",
    "Used by 200+ teams in [industry]"
  ],
  "icp": {
    "industries": ["SaaS", "FinTech"],
    "company_size": "10-500",
    "titles": ["CEO", "CTO", "VP Engineering", "Head of Product"],
    "signals": ["recently funded", "hiring engineers", "launched new product"]
  },
  "sender": {
    "name": "Your Name",
    "title": "Your Title",
    "email": "your@email.com",
    "calendar_link": "https://cal.com/you"
  },
  "cadence": {
    "follow_up_1_days": 3,
    "follow_up_2_days": 7,
    "follow_up_3_days": 14
  },
  "tone": "casual"
}
```

## Usage Examples

**Research a lead:**
> "Research Acme Corp for outreach"

**Draft initial email:**
> "Write a cold email to Sarah Chen, CTO at Acme Corp"

**Generate follow-up:**
> "Draft follow-up #2 for the Acme Corp lead"

**Batch prospect:**
> "Find 10 SaaS companies that recently raised Series A and draft personalized emails for each CTO"

**Handle response:**
> "Lead from Acme replied: 'Interesting but we're locked into a contract until Q3.' Draft a response."

## Best Practices

1. **Quality over quantity.** 10 personalized emails outperform 100 templates.
2. **Research first, write second.** Never draft without intel.
3. **Track everything.** The tracker is your CRM. Keep it updated.
4. **Respect the no.** Graceful exits build long-term reputation.
5. **Test subject lines.** Rotate 2-3 variations per campaign.
6. **Follow up.** 80% of deals close after the 5th touch. Most people stop at 1.

## Integration Notes

- Works with any email sending tool (Gmail API, SendGrid, etc.)
- Pair with a CRM skill for full pipeline management
- Can export leads to CSV for bulk import into HubSpot, Salesforce, etc.
