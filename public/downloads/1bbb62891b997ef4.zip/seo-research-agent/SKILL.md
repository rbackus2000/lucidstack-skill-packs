---
name: seo-research-agent
description: AI-powered SEO research and optimization agent. Performs keyword research, competitor analysis, content gap identification, on-page optimization, and technical SEO audits. Built for founders and marketers who need SEO strategy without hiring an agency.
---

# SEO Research Agent

## Overview

This skill turns your AI agent into an SEO strategist. It handles keyword research, competitive analysis, content optimization, and technical audits — giving you agency-quality SEO insights without the agency price tag.

## Capabilities

### 1. Keyword Research & Analysis

**Research Workflow:**
1. Take a seed topic or competitor URL
2. Generate keyword clusters (head terms + long-tail variations)
3. Classify by intent (informational, navigational, commercial, transactional)
4. Estimate difficulty and opportunity based on SERP analysis
5. Group into content themes for strategic planning

**Output Format:**
```
## Keyword Research: [Seed Topic]

### Primary Keywords
| Keyword | Intent | Difficulty | Opportunity | Content Type |
|---------|--------|-----------|-------------|-------------|
| [keyword] | commercial | high | medium | landing page |
| [keyword] | informational | low | high | blog post |
| [keyword] | transactional | medium | high | product page |

### Long-Tail Opportunities
| Keyword | Intent | Why It Matters |
|---------|--------|---------------|
| [long-tail keyword] | informational | Low competition, high conversion intent |

### Keyword Clusters
**Cluster 1: [Theme]**
- [keyword 1] (primary)
- [keyword 2] (secondary)
- [keyword 3] (supporting)
→ Recommended content: [type + topic]

**Cluster 2: [Theme]**
- [keyword 1] (primary)
- [keyword 2] (secondary)
→ Recommended content: [type + topic]

### Quick Wins
Keywords you could rank for within 3 months:
1. [keyword] — [why it's winnable]
2. [keyword] — [why it's winnable]
```

### 2. Competitor SEO Analysis

**Analysis Workflow:**
1. Identify top 3-5 competitors for a given keyword/niche
2. Analyze their top-ranking pages (structure, word count, content depth)
3. Identify keywords they rank for that you don't
4. Find content gaps — topics they haven't covered well
5. Assess their backlink authority signals

**Output Format:**
```
## Competitor Analysis: [Your Domain] vs [Competitors]

### Competitor Overview
| Competitor | Top Keywords | Content Volume | Strength | Weakness |
|-----------|-------------|---------------|----------|----------|
| [comp 1] | [est. count] | [est. pages] | [strength] | [gap] |
| [comp 2] | [est. count] | [est. pages] | [strength] | [gap] |

### Content Gaps (Topics They Miss)
1. **[Topic]** — [Why this is an opportunity for you]
2. **[Topic]** — [Why this is an opportunity for you]

### Keywords They Rank For (You Don't)
| Keyword | Competitor | Their Position | Your Opportunity |
|---------|-----------|---------------|-----------------|
| [keyword] | [comp] | [position] | [assessment] |

### Tactical Recommendations
1. [Specific action + expected impact]
2. [Specific action + expected impact]
3. [Specific action + expected impact]
```

### 3. On-Page SEO Optimization

**Analyze and optimize any page:**

**Checklist:**
- [ ] Title tag (under 60 chars, includes primary keyword)
- [ ] Meta description (under 160 chars, includes CTA)
- [ ] H1 tag (one per page, includes primary keyword)
- [ ] H2/H3 structure (logical hierarchy, includes secondary keywords)
- [ ] URL structure (short, descriptive, includes keyword)
- [ ] Internal linking (3-5 relevant internal links)
- [ ] Image alt text (descriptive, includes keywords naturally)
- [ ] Content length (competitive with top-ranking pages)
- [ ] Keyword density (natural usage, not stuffed)
- [ ] Schema markup recommendations
- [ ] Featured snippet optimization opportunities
- [ ] FAQ section opportunities (People Also Ask)

**Output:**
```
## On-Page SEO Audit: [URL]

**Target Keyword:** [primary keyword]
**Current Score:** [X/100]

### Issues Found
🔴 **Title tag missing primary keyword**
- Current: "[current title]"
- Recommended: "[optimized title]"

🟡 **Meta description too long (180 chars)**
- Current: "[current]"
- Recommended: "[optimized — 155 chars]"

🟢 **H1 tag properly optimized** ✓

### Content Recommendations
- Add section: "[topic]" (competitors cover this, you don't)
- Expand section: "[topic]" (your 200 words vs competitor avg 500)
- Add FAQ: [3-5 "People Also Ask" questions to answer]

### Schema Markup
Recommended schema types for this page:
- [SchemaType] — [why]
```

### 4. Content Brief Generation

**Create SEO-optimized content briefs:**

```
## Content Brief: [Target Keyword]

**Target Keyword:** [primary]
**Secondary Keywords:** [list]
**Search Intent:** [informational/commercial/transactional]
**Recommended Content Type:** [blog post/landing page/guide]

### SERP Analysis
- Top 3 results: [what they cover, avg word count, format]
- Featured snippet: [yes/no, type, opportunity]
- People Also Ask: [top 5 questions]

### Content Structure
**Title:** [SEO-optimized title]
**Meta Description:** [Optimized meta]
**URL:** /[recommended-slug]

**Outline:**
1. H2: [Section title]
   - Key points to cover
   - [Secondary keyword to include]

2. H2: [Section title]
   - Key points to cover

3. H2: [FAQ section]
   - Q: [PAA question 1]
   - Q: [PAA question 2]
   - Q: [PAA question 3]

**Recommended Length:** [X words] (based on competitor avg)
**Internal Links:** Link to [page 1], [page 2], [page 3]
**External Links:** Cite [source 1], [source 2]

### Differentiation Strategy
How to make this better than what's ranking:
- [Angle 1]
- [Angle 2]
- [Unique data/perspective to include]
```

### 5. Technical SEO Audit

**Site-level technical assessment:**

**Checks:**
- Site speed indicators (resource analysis)
- Mobile responsiveness signals
- Robots.txt configuration
- Sitemap.xml presence and structure
- Canonical tag usage
- 404/redirect chain issues
- Structured data validation
- Core Web Vitals recommendations
- Crawlability issues
- Duplicate content detection

### 6. SEO Tracking & Reporting

**Monthly SEO report template:**
```
## SEO Report: [Month Year]

### Key Metrics
| Metric | This Month | Last Month | Change |
|--------|-----------|------------|--------|
| Organic Traffic | [est.] | [est.] | [+/-] |
| Keywords Ranking | [count] | [count] | [+/-] |
| Top 10 Keywords | [count] | [count] | [+/-] |
| New Content Published | [count] | [count] | [+/-] |

### Top Performing Pages
1. [URL] — [keyword] — [position]
2. [URL] — [keyword] — [position]

### Opportunities for Next Month
1. [Action item]
2. [Action item]
3. [Action item]
```

## Configuration

Create `seo-config.json` in your workspace:

```json
{
  "domain": "yourdomain.com",
  "industry": "SaaS / Developer Tools",
  "target_audience": "Solo developers and small teams",
  "competitors": [
    "competitor1.com",
    "competitor2.com",
    "competitor3.com"
  ],
  "focus_keywords": [
    "AI developer tools",
    "code automation",
    "developer productivity"
  ],
  "content_types": ["blog", "landing-page", "docs"],
  "tracking_file": "seo-tracker.json"
}
```

## Usage Examples

**Keyword research:**
> "Research keywords for 'AI code review tools'"

**Competitor analysis:**
> "Analyze the SEO strategy of competitor.com vs our site"

**Optimize a page:**
> "Run an on-page SEO audit on our pricing page"

**Content brief:**
> "Create an SEO content brief for 'how to automate code reviews with AI'"

**Technical audit:**
> "Run a technical SEO check on buildtrace.cloud"

**Full strategy:**
> "Build a 3-month SEO strategy for our developer tools blog"

## Best Practices

1. **Intent first, keywords second.** Understand WHY someone searches before optimizing for WHAT they search.
2. **Quality over keyword density.** Google rewards comprehensive, helpful content — not keyword-stuffed pages.
3. **Build topic authority.** Cluster related content together. One great article < ten connected articles.
4. **Update existing content.** Refreshing a ranking page often beats writing a new one.
5. **Technical foundation matters.** Fast, mobile-friendly, crawlable. Fix the basics first.
6. **Patience is a strategy.** SEO compounds over months. Expect 3-6 months for meaningful results on competitive terms.
