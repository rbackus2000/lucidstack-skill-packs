# Customer Support Agent

AI-powered tier-1 support that actually sounds human. Triages tickets, drafts responses, manages escalations, builds a knowledge base, and tracks customer health — so you can sleep while your support stays responsive.

## What's Included

- `SKILL.md` — Complete agent skill with triage, response drafting, KB management, escalation handling, and analytics
- `support-config.example.json` — Product details, SLA settings, and tone configuration
- `support-kb.example.json` — Knowledge base template

## Quick Start

1. Copy this folder to your workspace `skills/` directory
2. Copy config examples to workspace root and customize
3. Start handling tickets: "New support ticket: [customer message]"

## Requirements

- Claude Code or OpenClaw
- Email/ticketing integration (optional — works with manual paste too)

## Example Commands

```
"Triage this support ticket: [customer message]"
"Draft a response for the billing dispute from john@acme.com"
"Search the KB for password reset instructions"
"Generate the weekly support summary"
"Show customer health for our top 10 accounts"
```

Built by LucidStack.ai
