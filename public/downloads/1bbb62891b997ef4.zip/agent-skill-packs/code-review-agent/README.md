# Code Review Agent

Senior-engineer-level code reviews on autopilot. Catches security vulnerabilities, performance issues, logic errors, and style violations — with actionable fixes, not vague complaints.

## What's Included

- `SKILL.md` — Complete agent skill with full review, security audit, performance analysis, and pre-commit checks
- `review-config.example.json` — Configuration for your language, framework, and custom rules

## Quick Start

1. Copy this folder to your workspace `skills/` directory
2. Copy `review-config.example.json` to workspace root as `review-config.json`
3. Customize for your stack (language, framework, style guide)
4. Start reviewing: "Review src/api/auth.ts for security issues"

## Requirements

- Claude Code or OpenClaw with file system access
- Git (for diff-based reviews)

## Example Commands

```
"Review this file for bugs and security issues"
"Run a security audit on the api/ directory"
"Check my staged changes before I commit"
"Find performance issues in the React components"
"Review the architecture of this project"
```

Built by LucidStack.ai
