---
name: code-review-agent
description: >
  Automated code review agent that analyzes pull requests, identifies security
  vulnerabilities, enforces coding standards, and provides actionable feedback.
  Works with any language/framework. Built for solo devs and small teams who
  need senior-engineer-level reviews without the senior engineer.
version: 1.0.0
author: LucidStack.ai
tags: [code-review, security, quality, automation, development]
---

# Code Review Agent

## Overview

This skill gives your AI agent the ability to perform thorough, opinionated code reviews. It catches bugs, security issues, performance problems, and style violations — then explains WHY something is wrong and HOW to fix it, not just WHAT is wrong.

## Capabilities

### 1. Full Code Review

When given a file, diff, or PR:

**Review Checklist:**
- [ ] Logic errors and edge cases
- [ ] Security vulnerabilities (injection, XSS, auth bypass, secrets exposure)
- [ ] Performance issues (N+1 queries, unnecessary re-renders, memory leaks)
- [ ] Error handling (missing try/catch, unhandled promise rejections, silent failures)
- [ ] Type safety (TypeScript strict mode violations, any-casts, missing types)
- [ ] API design (REST conventions, error responses, input validation)
- [ ] Database queries (SQL injection, missing indexes, transaction handling)
- [ ] Dependencies (outdated packages, known vulnerabilities, unnecessary imports)
- [ ] Testing gaps (untested paths, missing edge case tests)
- [ ] Code style (naming, structure, DRY violations, dead code)

**Output Format:**
```
## Code Review: [file/PR name]

### 🔴 Critical (must fix)
**[File:Line]** — [Issue title]
> [Code snippet]
**Problem:** [What's wrong and why it matters]
**Fix:** [Exact code fix or approach]

### 🟡 Warning (should fix)
**[File:Line]** — [Issue title]
> [Code snippet]
**Problem:** [Explanation]
**Fix:** [Suggestion]

### 🟢 Suggestions (nice to have)
- [Minor improvement 1]
- [Minor improvement 2]

### ✅ What's Good
- [Positive observation 1]
- [Positive observation 2]

**Overall:** [1-2 sentence summary and confidence level]
```

### 2. Security-Focused Review

Deep security analysis with OWASP Top 10 mapping:

**Checks:**
| Category | What It Catches |
|----------|----------------|
| **Injection** | SQL injection, NoSQL injection, command injection, LDAP injection |
| **Broken Auth** | Weak password policies, missing MFA hooks, session fixation |
| **Sensitive Data** | Hardcoded secrets, PII in logs, missing encryption |
| **XXE** | XML parser misconfigurations |
| **Broken Access Control** | Missing auth checks, IDOR vulnerabilities, privilege escalation |
| **Misconfig** | Debug mode in prod, default credentials, verbose errors |
| **XSS** | Reflected, stored, DOM-based cross-site scripting |
| **Insecure Deserialization** | Unsafe JSON/YAML parsing, prototype pollution |
| **Vulnerable Components** | Known CVEs in dependencies |
| **Logging** | Missing audit trails, sensitive data in logs |

**Security Output:**
```
## Security Review: [file/PR]

**Risk Level:** HIGH | MEDIUM | LOW

### Findings
1. **[CRITICAL]** SQL Injection in user search
   - File: `api/users.js:45`
   - OWASP: A03:2021 Injection
   - Impact: Full database read/write
   - Fix: Use parameterized queries
   
2. **[HIGH]** Hardcoded API key
   - File: `config/api.js:12`
   - OWASP: A02:2021 Cryptographic Failures
   - Impact: API key exposed in source control
   - Fix: Move to environment variables

### Dependency Audit
- [package@version] — CVE-XXXX-XXXX (severity)
```

### 3. Performance Review

Identify performance bottlenecks:

**Frontend:**
- Unnecessary re-renders (React)
- Missing memoization (useMemo, useCallback, React.memo)
- Bundle size impact (large imports, tree-shaking issues)
- Layout thrashing, forced reflows
- Missing lazy loading (images, routes, components)

**Backend:**
- N+1 query patterns
- Missing database indexes
- Unoptimized aggregations
- Missing caching opportunities
- Synchronous operations that should be async
- Memory leaks (event listeners, timers, closures)

**API:**
- Over-fetching / under-fetching
- Missing pagination
- No rate limiting
- Redundant middleware

### 4. Pre-Commit Review

Quick review before committing:

```
"Review these changes before I commit"
```

Agent will:
1. Run `git diff --staged` (or review provided changes)
2. Quick-check for secrets, debug code, console.logs, TODO comments
3. Verify no test files are broken
4. Flag anything that shouldn't be committed
5. Give a go/no-go recommendation

### 5. Architecture Review

Zoom out from code to design:

```
"Review the architecture of this project"
```

Agent will examine:
- File/folder structure and organization
- Separation of concerns
- Dependency graph complexity
- API surface design
- Database schema design
- Error handling strategy
- Testing strategy
- Deployment considerations

## Configuration

Create `review-config.json` in your workspace:

```json
{
  "language": "typescript",
  "framework": "next.js",
  "style_guide": "airbnb",
  "severity_threshold": "warning",
  "focus_areas": ["security", "performance", "types"],
  "ignore_patterns": ["*.test.ts", "*.spec.ts", "node_modules/**"],
  "custom_rules": [
    {
      "name": "no-any",
      "description": "Disallow 'any' type in TypeScript",
      "severity": "warning"
    },
    {
      "name": "require-error-handling",
      "description": "All async functions must have error handling",
      "severity": "error"
    }
  ]
}
```

## Usage Examples

**Review a file:**
> "Review src/api/auth.ts for security issues"

**Review a PR/diff:**
> "Review the changes in my last commit"

**Security audit:**
> "Run a security review on the entire api/ directory"

**Pre-commit check:**
> "Quick review before I push — anything I'm missing?"

**Architecture review:**
> "Review the overall architecture of this Next.js project"

**Performance check:**
> "Find performance issues in the dashboard components"

## Best Practices

1. **Review early, review often.** Don't wait for massive PRs. Review as you build.
2. **Fix criticals immediately.** Security issues don't wait for the next sprint.
3. **Learn from reviews.** The best reviews teach patterns, not just catch bugs.
4. **Configure for your stack.** Customize the config to match your conventions.
5. **Automate the boring stuff.** Let the agent catch the linting issues so humans can focus on logic and design.
