# Content Pipeline Agent

Your AI-powered content team. Monitors trends, writes multi-platform content, manages your editorial calendar, and handles the full draft → approve → publish workflow.

## What's Included

- `SKILL.md` — Complete agent skill with trend monitoring, content generation, calendar management, and publishing workflows
- `content-config.example.json` — Brand voice, platform settings, and content pillar configuration
- `content-calendar.example.json` — Editorial calendar template

## Quick Start

1. Copy this folder to your workspace `skills/` directory
2. Copy config examples to your workspace root and customize
3. Start creating: "Scan for trending topics and draft today's post"

## Requirements

- Claude Code or OpenClaw with web search capability
- Platform APIs for automated publishing (optional — can publish manually)

## Example Commands

```
"What's trending in [your industry] today?"
"Draft a LinkedIn post about [topic]"
"Turn this blog post into a Twitter thread"
"Show me this week's content calendar"
"Run the daily content pipeline"
```

Built by LucidStack.ai
