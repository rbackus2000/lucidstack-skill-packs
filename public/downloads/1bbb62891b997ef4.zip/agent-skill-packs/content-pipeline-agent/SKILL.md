---
name: content-pipeline-agent
description: >
  End-to-end content creation and publishing pipeline. Monitors industry trends,
  generates multi-platform content (LinkedIn, X/Twitter, blog), manages an editorial
  calendar, and handles approval workflows. Built for founders who need consistent
  content without hiring a content team.
version: 1.0.0
author: LucidStack.ai
tags: [content, social-media, marketing, automation, publishing]
---

# Content Pipeline Agent

## Overview

This skill turns your AI agent into a full content operations team. It handles trend monitoring, content ideation, multi-platform drafting, editorial calendar management, and publishing workflows — so you can maintain a consistent presence without the time investment.

## Capabilities

### 1. Industry Monitoring & Trend Detection

**Daily scan workflow:**
1. Search 3-5 industry-specific queries (configured per your niche)
2. Identify trending topics, news, and conversations
3. Score each for content potential (relevance × timeliness × engagement potential)
4. Generate content angles tied to your products/expertise

**Monitoring Config:**
```json
{
  "industries": ["AI tools", "developer experience", "indie hacking"],
  "search_queries": [
    "AI developer tools news",
    "indie hacker launches this week",
    "developer productivity trends"
  ],
  "competitors": ["competitor1.com", "competitor2.com"],
  "scan_frequency": "daily"
}
```

### 2. Multi-Platform Content Generation

**LinkedIn Posts (thought leadership):**
- 150-300 words
- Hook in first line (pattern interrupt or bold claim)
- Story or data in the body
- CTA or discussion question at end
- Strategic hashtag placement (3-5 relevant tags)
- Format: short paragraphs, line breaks for readability

**X/Twitter Threads:**
- 3-7 tweet thread format
- Tweet 1: attention-grabbing stat, question, or hot take
- Middle tweets: insight, story, or step-by-step
- Final tweet: CTA, link, or ask for engagement
- Each tweet stands alone but flows as a narrative
- Under 280 chars per tweet

**X/Twitter Single Posts:**
- Punchy, opinionated, or insightful
- Under 280 characters
- Optimized for engagement (questions, hot takes, listicles)

**Blog Posts:**
- SEO-optimized title and meta description
- 800-1500 words
- Clear H2/H3 structure
- Actionable takeaways
- Internal/external linking suggestions
- CTA at bottom

**Email Newsletter:**
- Subject line (A/B options)
- 300-500 words
- One key insight or story
- One CTA
- Conversational tone

### 3. Editorial Calendar Management

**Calendar stored in `content-calendar.json`:**
```json
{
  "schedule": {
    "monday": { "platform": "linkedin", "theme": "industry-insight" },
    "tuesday": { "platform": "twitter", "theme": "tactical-tip" },
    "wednesday": { "platform": "blog", "theme": "deep-dive" },
    "thursday": { "platform": "twitter", "theme": "hot-take" },
    "friday": { "platform": "linkedin", "theme": "founder-story" }
  },
  "queue": [
    {
      "id": "2026-03-06-001",
      "date_created": "2026-03-06",
      "platform": "linkedin",
      "theme": "industry-insight",
      "topic": "Why AI agents are replacing SaaS dashboards",
      "angle": "The best UI is no UI — agents that just do the work",
      "product_tie": "Agent Studio",
      "draft": "[Full post text]",
      "status": "pending_approval",
      "scheduled_date": "2026-03-10",
      "priority": "high"
    }
  ]
}
```

### 4. Content Repurposing Engine

Turn one piece of content into multiple formats:

**Blog Post → generates:**
- 3 LinkedIn post variations
- 5 tweet variations
- 1 email newsletter edition
- 1 Twitter thread
- Pull quotes for graphics

**Podcast/Video transcript → generates:**
- Key takeaway blog post
- Quote cards (text descriptions for design)
- Social media clips (timestamp markers)
- Twitter thread summary

### 5. Approval & Publishing Workflow

**States:** `idea` → `drafted` → `pending_approval` → `approved` → `scheduled` → `published`

**Commands:**
- "What's in the content queue?" → Show all pending items
- "Draft a post about [topic]" → Create draft, add to queue
- "Approve [id]" → Move to approved
- "Schedule [id] for [date]" → Set publish date
- "Post [id]" → Publish to platform
- "Show me this week's calendar" → Display scheduled content

### 6. Performance Tracking

After publishing, track engagement metrics:
```json
{
  "published": [
    {
      "id": "2026-03-06-001",
      "platform": "linkedin",
      "published_date": "2026-03-06",
      "url": "https://linkedin.com/...",
      "metrics": {
        "impressions": null,
        "likes": null,
        "comments": null,
        "shares": null,
        "clicks": null
      },
      "notes": "Best performing post this month"
    }
  ]
}
```

## Configuration

Create `content-config.json` in your workspace:

```json
{
  "brand": {
    "name": "Your Brand",
    "voice": "Confident, technical, slightly irreverent",
    "topics": ["AI", "developer tools", "indie hacking", "building in public"],
    "products": [
      {
        "name": "Product Name",
        "url": "https://yourproduct.com",
        "one_liner": "What it does in one sentence"
      }
    ],
    "hashtags": ["#BuildInPublic", "#IndieHacker", "#AI"]
  },
  "platforms": {
    "linkedin": { "enabled": true, "frequency": "2x/week" },
    "twitter": { "enabled": true, "frequency": "daily" },
    "blog": { "enabled": true, "frequency": "weekly" },
    "newsletter": { "enabled": false, "frequency": "weekly" }
  },
  "content_pillars": [
    "Behind-the-scenes building",
    "Industry insights and trends",
    "Tactical tips and tutorials",
    "Product updates and launches",
    "Founder lessons and stories"
  ]
}
```

## Usage Examples

**Generate content ideas:**
> "Scan for trending topics in AI dev tools and give me 5 content ideas"

**Draft specific content:**
> "Write a LinkedIn post about why solo devs need AI agents, not more SaaS tools"

**Manage the queue:**
> "Show me what's pending approval in the content queue"

**Repurpose content:**
> "Turn this blog post into a Twitter thread and 3 LinkedIn posts"

**Full pipeline:**
> "Run the daily content pipeline — scan trends, draft today's scheduled post, show me what's due"

## Best Practices

1. **Consistency > virality.** Show up regularly. The algorithm rewards frequency.
2. **80/20 rule.** 80% value-add content, 20% product mentions.
3. **Engage, don't broadcast.** Reply to comments on your posts. Build relationships.
4. **Repurpose aggressively.** One good idea = 5+ pieces of content across platforms.
5. **Track what works.** Double down on formats and topics that perform.
6. **Authentic voice.** Write like you talk. If it sounds like ChatGPT wrote it, rewrite it.
