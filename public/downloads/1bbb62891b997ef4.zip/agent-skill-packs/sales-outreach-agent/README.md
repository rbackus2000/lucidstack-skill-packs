# Sales Outreach Agent

Your AI-powered sales development rep. Researches leads, writes personalized cold emails that don't sound like cold emails, and manages follow-up sequences automatically.

## What's Included

- `SKILL.md` — Complete agent skill with lead research, email drafting, follow-up management, and response analysis
- `outreach-config.example.json` — Configuration template for your company, ICP, and cadence settings
- `outreach-tracker.example.json` — Lead tracking template

## Quick Start

1. Copy this folder to your workspace `skills/` directory
2. Copy `outreach-config.example.json` to your workspace root as `outreach-config.json`
3. Fill in your company details, value prop, and ICP criteria
4. Start prospecting: "Research [company] for outreach"

## Requirements

- Claude Code or OpenClaw with web search capability
- Email sending integration (Gmail API, SendGrid, or manual)

## Example Commands

```
"Research Stripe for outreach"
"Write a cold email to the VP of Engineering at Vercel"
"Draft follow-up #2 for the Datadog lead"
"Find 5 recently-funded DevTool startups and draft outreach for each"
```

Built by LucidStack.ai
