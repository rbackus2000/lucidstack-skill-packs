# SEO Research Agent

Agency-quality SEO research and optimization without the agency. Keyword research, competitor analysis, content briefs, on-page audits, and technical SEO — all automated through your AI agent.

## What's Included

- `SKILL.md` — Complete agent skill with keyword research, competitor analysis, on-page optimization, content brief generation, and technical audits
- `seo-config.example.json` — Domain, competitor, and tracking configuration

## Quick Start

1. Copy this folder to your workspace `skills/` directory
2. Copy `seo-config.example.json` to workspace root as `seo-config.json`
3. Customize with your domain, competitors, and target keywords
4. Start researching: "Research keywords for [your niche]"

## Requirements

- Claude Code or OpenClaw with web search capability
- Access to your website for technical audits

## Example Commands

```
"Research keywords for 'AI developer tools'"
"Analyze competitor.com's SEO strategy"
"Create a content brief for 'how to automate deployments'"
"Run an on-page SEO audit on our homepage"
"Build a 3-month SEO plan for our blog"
```

Built by LucidStack.ai
