# LucidStack Agent Skill Packs

Premium, production-ready AI agent skills for Claude Code and OpenClaw.

Each skill pack includes:
- Complete SKILL.md with structured prompts and workflows
- Supporting scripts and automation
- Setup guide with examples
- Ready to drop into any Claude Code or OpenClaw workspace

## Packs Included

1. **Sales Outreach Agent** — Automated lead research, personalized email drafting, follow-up sequences
2. **Content Pipeline Agent** — Multi-platform content creation, scheduling, and publishing workflows
3. **Code Review Agent** — Automated PR reviews, security scanning, best practice enforcement
4. **Customer Support Agent** — Ticket triage, response drafting, escalation routing
5. **SEO Research Agent** — Keyword research, competitor analysis, content optimization

## Installation

1. Copy the skill folder into your workspace `skills/` directory
2. The agent will automatically detect and use the skill when relevant tasks arise
3. Customize the SKILL.md parameters for your specific use case

## Requirements

- Claude Code CLI or OpenClaw gateway
- API keys for relevant integrations (noted in each skill's README)

## License

Single-user commercial license. See LICENSE.md for details.

Built by LucidStack.ai — AI tools for builders who ship.
