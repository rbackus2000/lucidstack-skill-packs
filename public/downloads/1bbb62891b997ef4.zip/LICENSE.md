# LucidStack Agent Skill Packs — License

## Single-User Commercial License

Copyright © 2026 LucidStack.ai LLC. All rights reserved.

### Grant of License

Upon purchase, you are granted a non-exclusive, non-transferable, perpetual license to:

1. **Use** the skill packs in your own AI agent workflows (personal or commercial)
2. **Modify** the skill files to suit your specific use case
3. **Deploy** modified versions within your own organization

### Restrictions

You may NOT:

1. **Redistribute** the skill packs (modified or unmodified) to others
2. **Resell** the skill packs or derivative works based on them
3. **Share** your purchase with other individuals or organizations
4. **Include** the skill packs in other products for sale

### Team License

For team usage (multiple users within one organization), contact hello@lucidstack.ai for team pricing.

### Refund Policy

30-day money-back guarantee. No questions asked.

### Support

For questions, issues, or feature requests: hello@lucidstack.ai

### Disclaimer

THE SKILL PACKS ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. LUCIDSTACK.AI LLC SHALL NOT BE LIABLE FOR ANY DAMAGES ARISING FROM THE USE OF THESE SKILL PACKS.
