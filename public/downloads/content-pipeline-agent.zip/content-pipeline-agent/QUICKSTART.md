# Content Pipeline Agent — Quick Start

## Setup (5 minutes)

1. Copy `SKILL.md` into your Claude Code skills directory
2. Copy `content-config.template.json` → `content-config.json` in your workspace
3. Copy `content-calendar.template.json` → `content-calendar.json` in your workspace
4. Edit `content-config.json`:
   - Replace brand name, voice, and topics with yours
   - Add your products with URLs and one-liners
   - Set which platforms you use and posting frequency
   - Define your 3-5 content pillars
   - Add competitor domains and search queries for trend monitoring

## First Run

Try these commands to test your setup:

> "Scan for trending topics in [your industry] and give me 5 content ideas"

> "What should I post this week?"

> "Draft a LinkedIn post about [your product's key feature]"

## Daily Workflow

1. **Morning:** "Run the daily content pipeline" — scans trends, drafts scheduled posts
2. **Review:** "Show me what's pending approval" — review and approve drafts
3. **Publish:** "Post [id]" — publishes approved content
4. **Track:** Update metrics after 24-48 hours

## Tips

- Fill in the `voice` field with how YOU write, not how you want AI to write. Include 2-3 example posts if possible.
- Start with 2 platforms, not 5. Add more once you have a rhythm.
- The 80/20 rule: 80% value content, 20% product mentions. The agent follows this automatically.
- Review every draft before publishing — the agent gets better as you edit and it learns your preferences.
